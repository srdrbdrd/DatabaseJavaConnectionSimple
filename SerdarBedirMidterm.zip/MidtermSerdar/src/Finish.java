

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




/**
 * Servlet implementation class Finish
 */
@WebServlet("/Finish")
public class Finish extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Finish() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Your Basket</h1>");
       try { 
        String dbURL = "jdbc:mysql://localhost:3306/"; 
	        String dbName = "basket"; 
	        String dbUsername = "root"; 
	        String dbPassword = ""; 
	  
	        Class.forName("com.mysql.jdbc.Driver"); 
	        Connection con = DriverManager.getConnection(dbURL + dbName, 
	                                                     dbUsername,  
	                                                     dbPassword); 
	        System.out.println("Ba�land�");
	        int toplam=0;
	        Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from basketc");
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>Product</th><th>Price $</th><tr>");
            while (rs.next()) {
                String n = rs.getString("Urun");
                int s = rs.getInt("Fiyat"); 
                toplam = s+toplam;
                out.println("<tr><td>" + n + "</td><td>" + s + "</td></tr>"); 
            }
            out.println("</table>");
            out.println("<form action=\"Shop.html\" method=\"post\">"
            		+ "<input type=\"submit\" value=\"Continue Shopping\">"
            		+ "</form>");
            out.print("<b>Total price =" + toplam +"$</b>" );
            out.println("<form action=\"Logout\" method=\"post\">"
            		+ "<input type=\"submit\" value=\"Buy\">"
            		+ "</form>");
            out.println("</html></body>");
            con.close();
           
	}catch (ClassNotFoundException | SQLException e) {
 	    // TODO Auto-generated catch block
 	    e.printStackTrace();
 	   }

}}
