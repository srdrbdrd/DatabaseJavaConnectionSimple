

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
	
        String ID = request.getParameter("ID");
        String Password = request.getParameter("Password");
        if (request.getParameter("Register") != null) {
        try {
         String dbURL = "jdbc:mysql://localhost:3306/"; 
 	        String dbName = "login"; 
 	        String dbUsername = "root"; 
 	        String dbPassword = ""; 
 	  
 	        Class.forName("com.mysql.jdbc.Driver"); 
 	        Connection con = DriverManager.getConnection(dbURL + dbName, 
 	                                                     dbUsername,  
 	                                                     dbPassword); 
 	        System.out.println("Ba�land�");
 	        
 	       String query1 = "select * from giris where id=? and password=?";
	        PreparedStatement ps1 = con.prepareStatement(query1);
	        
	        ps1.setString(1, ID);
	        ps1.setString(2, Password);
	       ResultSet rs= ps1.executeQuery();
	       
	       if(rs.next()) {
	    	   out.print("Select other password/id.The User Already Exist "+ID);
	        	out.print("<a href='Register.html'>Register/Login</a>");
	       }else {
 	        
 	        String query = "insert into giris values (?,?)";
 	        PreparedStatement ps = con.prepareStatement(query);
 	        
 	        ps.setString(1, ID);
 	        ps.setString(2, Password);
 	       int i = ps.executeUpdate();
        
        if(i>0) {
        	 HttpSession session=request.getSession();  
             session.setAttribute("ID",ID);  
             RequestDispatcher rd = request.getRequestDispatcher("Shop.html");
	        	rd.forward(request, response);
        	
        }  }
            
        }
 	       catch (ClassNotFoundException | SQLException e) {
 	    	    // TODO Auto-generated catch block
 	    	    e.printStackTrace();
 	    	   }
	}else if (request.getParameter("Login") != null) {
		try {
	         String dbURL = "jdbc:mysql://localhost:3306/"; 
	 	        String dbName = "login"; 
	 	        String dbUsername = "root"; 
	 	        String dbPassword = ""; 
	 	  
	 	        Class.forName("com.mysql.jdbc.Driver"); 
	 	        Connection con = DriverManager.getConnection(dbURL + dbName, 
	 	                                                     dbUsername,  
	 	                                                     dbPassword); 
	 	        System.out.println("Ba�land�");
	 	        
	 	        String query = "select * from giris where id=? and password=?";
	 	        PreparedStatement ps = con.prepareStatement(query);
	 	        
	 	        ps.setString(1, ID);
	 	        ps.setString(2, Password);
	 	       ResultSet rs= ps.executeQuery();
	        
	        if (rs.next()) {
	        	 HttpSession session=request.getSession();  
	             session.setAttribute("ID",ID);  
	        	
	        	RequestDispatcher rd = request.getRequestDispatcher("Shop.html");
	        	rd.forward(request, response);
	        	
	        } else { 
	        out.print("Wrong user...");
	        out.print("<a href='Register.html'>Login/Register</a>");  } 
	        }
	 	       catch (ClassNotFoundException | SQLException e) {
	 	    	    // TODO Auto-generated catch block
	 	    	    e.printStackTrace();
	 	    	   }
		
	
	}else if (request.getParameter("DeleteUser") != null) {
		try {
	         String dbURL = "jdbc:mysql://localhost:3306/"; 
	 	        String dbName = "login"; 
	 	        String dbUsername = "root"; 
	 	        String dbPassword = ""; 
	 	  
	 	        Class.forName("com.mysql.jdbc.Driver"); 
	 	        Connection con = DriverManager.getConnection(dbURL + dbName, 
	 	                                                     dbUsername,  
	 	                                                     dbPassword); 
	 	        System.out.println("Ba�land�");
	 	        
	 	        String query = "delete from giris where id=? and password=?";
	 	        PreparedStatement ps = con.prepareStatement(query);
	 	        
	 	        ps.setString(1, ID);
	 	        ps.setString(2, Password);
	 	       int i= ps.executeUpdate();
	        
	        if(i>0) {
	        	HttpSession session = request.getSession(false);
	    		session.invalidate();
	    		out.print("User Deleted");
	    		out.print("<a href='Register.html'>Login/Register</a>");
	        	
	        	
	        	
	        } else { 
	        out.print("Wrong UserName...");
	        out.print("<a href='Register.html'>Login/Register</a>");  } 
	        }
	 	       catch (ClassNotFoundException | SQLException e) {
	 	    	    // TODO Auto-generated catch block
	 	    	    e.printStackTrace();
	 	    	   }
		
	}
	}

}
